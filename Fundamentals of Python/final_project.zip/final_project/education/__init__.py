__all__ = ['organizations', 'users']
print(f'There are {__all__[0]} and {__all__[1]} modules in the package.')
print('The education has imported successfully.')
